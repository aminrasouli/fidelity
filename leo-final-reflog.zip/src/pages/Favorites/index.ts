export { default } from './Favorites';
