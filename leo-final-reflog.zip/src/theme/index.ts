export { default as palette } from './palette';
export { default as getTheme } from './theme';
export { ThemeContext } from './context/themeContext';
export { default as CustomThemeProvider } from './components/CustomThemeProvider';
